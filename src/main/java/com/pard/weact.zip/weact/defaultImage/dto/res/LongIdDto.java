package com.pard.weact.defaultImage.dto.res;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LongIdDto {
    private Long id;
}