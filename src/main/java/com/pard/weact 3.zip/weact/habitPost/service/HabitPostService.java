package com.pard.weact.habitPost.service;

import com.pard.weact.habitPost.dto.req.CreateHabitPostDto;
import com.pard.weact.habitPost.dto.res.PostResultListDto;
import com.pard.weact.habitPost.dto.res.PostResultOneDto;
import com.pard.weact.habitPost.entity.HabitPost;
import com.pard.weact.habitPost.repo.HabitPostRepo;
import com.pard.weact.liked.service.LikedService;
import com.pard.weact.memberInformation.entity.MemberInformation;
import com.pard.weact.memberInformation.repository.MemberInformationRepo;
import com.pard.weact.postPhoto.entity.PostPhoto;
import com.pard.weact.postPhoto.service.PostPhotoService;
import com.pard.weact.room.repository.RoomRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Service
public class HabitPostService {

    private final HabitPostRepo habitPostRepo;
    private final RoomRepo roomRepo;
    private final MemberInformationRepo memberRepo;
    private final PostPhotoService postPhotoService;
    private final LikedService likedService;

    public Long createHabitPost(CreateHabitPostDto dto, MultipartFile image) throws IOException {
        PostPhoto photo = postPhotoService.uploadAndSave(image, "habitposts");

        HabitPost post = HabitPost.builder()
                .message(dto.getMessage())
                .photo(photo)
                .room(roomRepo.findById(dto.getRoomId()).orElseThrow())
                .member(memberRepo.findById(dto.getMemberId()).orElseThrow())
                .date(LocalDate.now())
                .isHaemyeong(dto.getIsHaemyeong())
                .build();

        return habitPostRepo.save(post).getId();
    }

    public List<PostResultListDto> readAllInRoom(Long roomId, LocalDate date) {
        List<HabitPost> posts = habitPostRepo.findAllByRoomIdAndDate(roomId, date);
        List<PostResultListDto> result = new ArrayList<>();
        for (HabitPost post : posts) {
            result.add(convertListIntoDto(post));
        }
        return result;
    }

    public PostResultOneDto readOneInRoom(Long memberId, Long postId) {
        HabitPost post = habitPostRepo.findById(postId)
                .orElseThrow(() -> new IllegalArgumentException("해당 게시글이 존재하지 않습니다."));
        return convertOneIntoDto(post, memberId);
    }

    private PostResultListDto convertListIntoDto(HabitPost post) {
        String userName = post.getMember().getUser().getUserName();

        String path = null;
        if (post.getPhoto() != null) {
            path = postPhotoService.getPhotoPathById(post.getPhoto().getId());
        }

        Long likeCount = likedService.countLikes(post.getId());

        return PostResultListDto.builder()
                .userName(userName)
                .imageUrl(path)
                .likeCount(likeCount)
                .build();
    }

    private PostResultOneDto convertOneIntoDto(HabitPost post, Long viewingUserId) {
        String userName = post.getMember().getUser().getUserName();

        String path = null;
        if (post.getPhoto() != null) {
            path = postPhotoService.getPhotoPathById(post.getPhoto().getId());
        }

        Long likeCount = likedService.countLikes(post.getId());

        Boolean liked = null;
        if (viewingUserId != null) {
            MemberInformation viewingMember = memberRepo.findByUserIdAndRoomId(
                    viewingUserId, post.getRoom().getId()
            );

            liked = likedService.isLiked(post.getId(), viewingMember.getId());
        }

        return PostResultOneDto.builder()
                .userName(userName)
                .message(post.getMessage())
                .imageUrl(path)
                .likeCount(likeCount)
                .liked(liked)
                .build();
    }

}
