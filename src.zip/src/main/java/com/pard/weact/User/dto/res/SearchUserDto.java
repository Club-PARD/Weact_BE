package com.pard.weact.User.dto.res;

import lombok.*;

import java.util.List;

@AllArgsConstructor @NoArgsConstructor
@Getter @Setter @Builder
public class SearchUserDto {
    private Long id;
    private String userId;
}
